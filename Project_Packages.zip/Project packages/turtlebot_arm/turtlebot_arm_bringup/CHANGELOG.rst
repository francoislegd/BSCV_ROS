^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot_arm_bringup
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.3 (2014-09-20)
------------------

0.3.2 (2014-08-30)
------------------
* Use gripper_controller instead of gripper_controller.py, as the later doesn't get installed

0.3.1 (2014-08-22)
------------------

0.3.0 (2014-08-16)
------------------
* First indigo release